#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3.11 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
exec .venv/bin/python -m streamlit run app.py --server.address 127.0.0.1
